/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sakthi
 */
public class NewClass {
    public static void main(args dhina[])
    {
    Scanner in=new Scanner(System.in);
    int a;
    a=in.nextInt();
    if(a<0)
        System.out.println("The number is negative");
    if(a>0)
        System.out.println("The number is positive");
    if(a==0)
        System.out.println("The number is zero");
    
    }
    
}
