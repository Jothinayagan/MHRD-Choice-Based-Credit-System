import java.util.*;
class murugavel1
{
public static void main(String mur[])
{

Scanner in=new Scanner(System.in);
int a;
a=in.nextInt();
if(a<0)
System.out.println("Negative");
if(a>0)
System.out.println("Postive");
if(a==0)
System.out.println("Zero");
 }
}
